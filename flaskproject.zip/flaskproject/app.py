from flask import Flask, render_template, request, redirect, url_for  # type: ignore
import mysql.connector  # type: ignore

app = Flask(__name__)

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="050605",
        database="inventory_app"
    )

@app.route('/')
def home():
    return render_template('home.html')

# ---------------------- PRODUCTS ----------------------
@app.route('/products')
def products():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products")
    products = cursor.fetchall()
    cursor.execute("SELECT id, name FROM locations")
    locations = cursor.fetchall()
    conn.close()
    return render_template('products.html', products=products, locations=locations)

@app.route('/add_product', methods=['POST'])
def add_product():
    product_id = request.form['product_id']
    name = request.form['name']
    quantity = int(request.form['quantity'])
    location_id = int(request.form['location_id'])

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO products (product_id, name, quantity) VALUES (%s, %s, %s)",
                   (product_id, name, quantity))
    product_db_id = cursor.lastrowid

    cursor.execute("""
        INSERT INTO product_movements (product_id, from_location_id, to_location_id, quantity, movement_type)
        VALUES (%s, NULL, %s, %s, 'import')
    """, (product_db_id, location_id, quantity))

    conn.commit()
    conn.close()
    return redirect(url_for('products'))

@app.route('/edit_product/<int:id>')
def edit_product(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE id = %s", (id,))
    product = cursor.fetchone()
    cursor.execute("SELECT id, name FROM locations")
    locations = cursor.fetchall()
    conn.close()
    return render_template('edit_product.html', product=product, locations=locations)

@app.route('/update_product/<int:id>', methods=['POST'])
def update_product(id):
    product_id = request.form['product_id']
    name = request.form['name']
    quantity = int(request.form['quantity'])
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE products SET product_id=%s, name=%s, quantity=%s WHERE id=%s",
                   (product_id, name, quantity, id))
    conn.commit()
    conn.close()
    return redirect(url_for('products'))

@app.route('/delete_product/<int:id>')
def delete_product(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM products WHERE id=%s", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('products'))

# ---------------------- LOCATIONS ----------------------
@app.route('/locations')
def locations():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM locations")
    locations = cursor.fetchall()
    conn.close()
    return render_template('locations.html', locations=locations)

@app.route('/add_location', methods=['POST'])
def add_location():
    location_id = request.form['location_id']
    name = request.form['name']
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO locations (location_id, name) VALUES (%s, %s)", (location_id, name))
    conn.commit()
    conn.close()
    return redirect(url_for('locations'))

@app.route('/edit_location/<int:id>')
def edit_location(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM locations WHERE id = %s", (id,))
    location = cursor.fetchone()
    conn.close()
    return render_template('edit_location.html', location=location)

@app.route('/update_location/<int:id>', methods=['POST'])
def update_location(id):
    location_id = request.form['location_id']
    name = request.form['name']
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE locations SET location_id=%s, name=%s WHERE id=%s",
                   (location_id, name, id))
    conn.commit()
    conn.close()
    return redirect(url_for('locations'))

@app.route('/delete_location/<int:id>')
def delete_location(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM locations WHERE id=%s", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('locations'))

# ---------------------- MOVEMENTS ----------------------
@app.route('/movements')
def movements():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, product_id, name FROM products")
    products = cursor.fetchall()
    cursor.execute("SELECT id, name FROM locations")
    locations = cursor.fetchall()
    conn.close()
    return render_template('movements.html', products=products, locations=locations)

@app.route('/add_movement', methods=['POST'])
def add_movement():
    product_id = int(request.form['product_id'])
    from_location = request.form.get('from_location') or None
    to_location = request.form.get('to_location') or None
    quantity = int(request.form['quantity'])
    movement_type = request.form['movement_type']

    from_location = int(from_location) if from_location else None
    to_location = int(to_location) if to_location else None

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO product_movements (product_id, from_location_id, to_location_id, quantity, movement_type)
        VALUES (%s, %s, %s, %s, %s)
    """, (product_id, from_location, to_location, quantity, movement_type))
    conn.commit()
    conn.close()
    return redirect(url_for('movements'))

# ---------------------- REPORT ----------------------
@app.route('/report')
def report():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT
            p.name AS product_name,
            l.name AS location_name,
            GREATEST(0, SUM(
                CASE
                    WHEN pm.movement_type = 'import' AND pm.to_location_id = l.id THEN pm.quantity
                    WHEN pm.movement_type = 'export' AND pm.from_location_id = l.id THEN -pm.quantity
                    WHEN pm.movement_type = 'transfer' AND pm.to_location_id = l.id THEN pm.quantity
                    WHEN pm.movement_type = 'transfer' AND pm.from_location_id = l.id THEN -pm.quantity
                    ELSE 0
                END
            )) AS quantity
        FROM products p
        JOIN product_movements pm ON p.id = pm.product_id
        JOIN locations l ON l.id = pm.to_location_id OR l.id = pm.from_location_id
        GROUP BY p.id, l.id
        HAVING quantity > 0
        ORDER BY l.name, p.name
    """)
    report_data = cursor.fetchall()
    conn.close()
    return render_template('report.html', report_data=report_data)

if __name__ == '__main__':
    app.run(debug=True)
