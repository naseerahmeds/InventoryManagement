
from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="Inventory"
)
cursor = db.cursor()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/products")
def products():
    cursor.execute("SELECT * FROM Product")
    products = cursor.fetchall()
    return render_template("products.html", products=products)

@app.route("/add_product", methods=["POST"])
def add_product():
    name = request.form["name"]
    quantity = request.form["quantity"]
    locatorid = request.form["locatorid"]
    cursor.execute("INSERT INTO Product (product_id, product_name, product_quantity, product_locatorid) VALUES (NULL, %s, %s, %s)", (name, quantity, locatorid))
    db.commit()
    return redirect(url_for("products"))

@app.route("/delete_product/<int:product_id>")
def delete_product(product_id):
    cursor.execute("DELETE FROM Product WHERE product_id = %s", (product_id,))
    db.commit()
    return redirect(url_for("products"))

if __name__ == "__main__":
    app.run(debug=True)
