from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '050605',
    'database': 'Inventory'
}

def get_connection():
    return mysql.connector.connect(**db_config)

@app.route('/')
def home():
    return render_template('dashboard.html')

@app.route('/products')
def products():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Product")
    products = cursor.fetchall()
    conn.close()
    return render_template('index.html', products=products)

@app.route('/add_product', methods=['POST'])
def add_product():
    product_id = request.form['product_id']
    name = request.form['product_name']
    quantity = request.form['product_quantity']
    locatorid = request.form['product_locatorid']
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Product (product_id, product_name, product_quantity, product_locatorid) VALUES (%s, %s, %s, %s)", 
                   (product_id, name, quantity, locatorid))
    conn.commit()
    conn.close()
    return redirect('/products')

@app.route('/update_product/<int:product_id>', methods=['POST'])
def update_product(product_id):
    name = request.form['product_name']
    quantity = request.form['product_quantity']
    locatorid = request.form['product_locatorid']
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE Product SET product_name=%s, product_quantity=%s, product_locatorid=%s WHERE product_id=%s", 
                   (name, quantity, locatorid, product_id))
    conn.commit()
    conn.close()
    return redirect('/products')

@app.route('/delete_product/<int:product_id>', methods=['POST'])
def delete_product(product_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Product WHERE product_id=%s", (product_id,))
    conn.commit()
    conn.close()
    return redirect('/products')

@app.route('/locations')
def locations():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Location")
    locations = cursor.fetchall()
    conn.close()
    return render_template('location.html', locations=locations)

@app.route('/add_location', methods=['POST'])
def add_location():
    locatorid = request.form['locator_id']
    storename = request.form['store_name']
    address = request.form['address']
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Location (locator_id, store_name, address) VALUES (%s, %s, %s)", 
                   (locatorid, storename, address))
    conn.commit()
    conn.close()
    return redirect('/locations')

@app.route('/product_movements')
def movements():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ProductMovement")
    movements = cursor.fetchall()
    conn.close()
    return render_template('movement.html', movements=movements)

@app.route('/add_movement', methods=['POST'])
def add_movement():
    product_id = request.form['product_id']
    from_location = request.form['from_location']
    to_location = request.form['to_location']
    quantity = request.form['quantity']
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO ProductMovement (product_id, from_location, to_location, quantity) VALUES (%s, %s, %s, %s)", 
                   (product_id, from_location, to_location, quantity))
    # update stock balances here as needed
    conn.commit()
    conn.close()
    return redirect('/product_movements')

if __name__ == '__main__':
    app.run(debug=True)
