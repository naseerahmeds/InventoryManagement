CREATE DATABASE IF NOT EXISTS Inventory;
USE Inventory;

CREATE TABLE IF NOT EXISTS Product (
    product_id INT PRIMARY KEY NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    product_quantity INT,
    product_locatorid INT
);

CREATE TABLE IF NOT EXISTS Location (
    locator_id INT PRIMARY KEY NOT NULL,
    store_name VARCHAR(255),
    address VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS ProductMovement (
    movement_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    from_location INT,
    to_location INT,
    quantity INT,
    FOREIGN KEY (product_id) REFERENCES Product(product_id),
    FOREIGN KEY (from_location) REFERENCES Location(locator_id),
    FOREIGN KEY (to_location) REFERENCES Location(locator_id)
);
